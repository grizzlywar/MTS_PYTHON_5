# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class FilmsParserItem(scrapy.Item):
    Title = scrapy.Field()
    Genre = scrapy.Field()
    Director = scrapy.Field()
    Country = scrapy.Field()
    Year = scrapy.Field()

