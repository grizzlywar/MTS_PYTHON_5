import scrapy
import re


def clean_list(elements):
    """Удаляет пустые элементы и лишние запятые."""
    return [el.strip() for el in elements if el.strip() and el.strip() != ',']


def clean_text(text):
    """Очищает текст от лишних символов, ссылок и форматирования."""
    if not text:
        return ""

    text = re.sub(r'\s*\[[^\]]*\]\s*', '', text)  # Убираем ссылки в квадратных скобках
    text = re.sub(r'\.mw-parser-output.*?\}', '', text)  # Убираем CSS-стили
    text = text.replace('/', '')  # Убираем слэши
    text = re.sub(r'\s*,\s*', ', ', text)  # Форматируем запятые
    return text.strip(', ').strip()


def clean_movie_title(title):
    """Удаляет лишние слова в скобках (например, 'фильм 1991 года')."""
    if not title:
        return ""

    title = re.sub(r'\s*\(фильм.*\)$', '', title, flags=re.IGNORECASE).strip()
    return clean_text(title)


class MovieItem(scrapy.Item):
    """Структура данных для хранения информации о фильме."""
    title = scrapy.Field()
    genre = scrapy.Field()
    director = scrapy.Field()
    country = scrapy.Field()
    year = scrapy.Field()


class MovieSpider(scrapy.Spider):
    """Паук Scrapy для парсинга фильмов с Википедии."""
    name = "movies"
    allowed_domains = ["ru.wikipedia.org"]

    start_urls = [
        'https://ru.wikipedia.org/w/index.php?title=Категория:Фильмы_1991_года&pageuntil=Капитан+Крокус+и+тайна+маленьких+заговорщиков#mw-pages'
    ]

    def parse(self, response):
        """Парсит список фильмов со страницы категории."""
        if not response or not response.body:
            self.logger.error("Пустой ответ от сервера")
            return

        movie_links = response.xpath('//div[@id="mw-pages"]//li/a/@href').getall()
        if not movie_links:
            self.logger.warning("Не найдено ссылок на фильмы")
            return

        for link in movie_links:
            if link.startswith("/wiki/Категория:"):
                continue
            yield response.follow(link, callback=self.parse_movie)

        next_page = response.xpath('//a[contains(text(),"Следующая страница")]/@href').get()
        if next_page:
            yield response.follow(next_page, callback=self.parse, dont_filter=True)

    def parse_movie(self, response):
        """Парсит страницу конкретного фильма."""
        if not response or not response.body:
            self.logger.error(f"Пустая страница: {response.url}")
            return

        if "/wiki/Категория:" in response.url:
            self.logger.info(f"Ссылка ведет на категорию, пропускаем: {response.url}")
            return

        item = MovieItem()

        # Парсим заголовок страницы
        raw_title = response.xpath("//h1[@id='firstHeading']//text()").get()
        if raw_title:
            title = clean_movie_title(raw_title.strip())
            if not title or title.lower() in ["категория", "результаты поиска"]:
                self.logger.info(f"Пропускаем страницу с заголовком '{title}': {response.url}")
                return
            item['title'] = title
        else:
            item['title'] = ''

        # Значения по умолчанию
        item['year'] = ""
        item['genre'] = ""
        item['director'] = ""
        item['country'] = ""

        # Парсим инфобокс, если он есть
        infobox = response.xpath("//table[contains(@class, 'infobox')]")
        if infobox:
            for row in infobox.xpath(".//tr"):
                header = ''.join(row.xpath(".//th//text()").getall()).strip().lower()
                if not header:
                    continue

                # Определяем, какие данные парсить
                if "жанр" in header:
                    genres = row.xpath(".//td//text()[not(ancestor::sup)]").getall()
                    item['genre'] = ", ".join(filter(None, [clean_text(g) for g in clean_list(genres)]))

                elif "режисс" in header:
                    directors = row.xpath(".//td//text()[not(ancestor::sup)]").getall()
                    item['director'] = ", ".join(filter(None, [clean_text(d) for d in clean_list(directors)]))

                elif "стран" in header:
                    countries = row.xpath(".//td//text()[not(ancestor::sup)]").getall()
                    item['country'] = ", ".join(filter(None, [clean_text(c) for c in clean_list(countries)]))

                elif "год" in header or "дата" in header:
                    year_text = " ".join(row.xpath(".//td//text()[not(ancestor::sup)]").getall())
                    match = re.search(r'\d{4}', year_text)
                    if match:
                        item['year'] = match.group(0)
        else:
            self.logger.info(f"Инфобокс не найден на странице: {response.url}")

        yield item

